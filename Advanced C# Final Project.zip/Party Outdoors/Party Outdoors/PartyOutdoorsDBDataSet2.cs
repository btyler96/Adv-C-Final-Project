﻿namespace Party_Outdoors
{


    public partial class PartyOutdoorsDBDataSet
    {
    }
}
namespace Party_Outdoors {
    
    
    public partial class PartyOutdoorsDBDataSet {
    }
}

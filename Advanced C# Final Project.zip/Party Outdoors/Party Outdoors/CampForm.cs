﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Party_Outdoors
{
    public partial class CampForm : Form
    {
        public static SqlConnection sqlCON = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=G:\CIS466 FA17\CH 11\Party Outdoors\Party Outdoors\PartyOutdoorsDB.mdf;Integrated Security = True; Connect Timeout = 30");

        public CampForm()
        {
            InitializeComponent();
            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["Tag"].ToString() == "Camp")
                {
                    campListBox.Items.Add(dr["ItemName"]).ToString();
                }
     
            }
            sqlCON.Close();

        }

        private void checkoutCButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerInfoForm CustomerInfoForm = new CustomerInfoForm();
            CustomerInfoForm.ShowDialog();
            this.Close();
        }

        private void backCButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm MainForm = new MainForm();
            MainForm.ShowDialog();
            this.Close();
        }

        private void gearTableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.gearTableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.partyOutdoorsDBDataSet);

        }

        private void CampForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'partyOutdoorsDBDataSet.GearTable' table. You can move, or remove it, as needed.
            //this.gearTableTableAdapter.FillByCamp(this.partyOutdoorsDBDataSet.GearTable);

        }

        private void showTentsButton_Click(object sender, EventArgs e)
        {
            campListBox.Items.Clear();

            this.gearTableTableAdapter.FillByTents(this.partyOutdoorsDBDataSet.GearTable);

            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "Tents")
                {
                    campListBox.Items.Add(dr["ItemName"]).ToString();                    
                }                
            }
            sqlCON.Close();

        }

        private void showSleepingBagsButton_Click(object sender, EventArgs e)
        {
            campListBox.Items.Clear();

            this.gearTableTableAdapter.FillBySleepingBags(this.partyOutdoorsDBDataSet.GearTable);

            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "Sleeping Bags")
                {
                    campListBox.Items.Add(dr["ItemName"]).ToString();

                }


            }
            sqlCON.Close();
        }

        private void showPacksButton_Click(object sender, EventArgs e)
        {
            campListBox.Items.Clear();

            this.gearTableTableAdapter.FillByPacks(this.partyOutdoorsDBDataSet.GearTable);

            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "Packs")
                {
                    campListBox.Items.Add(dr["ItemName"]).ToString();

                }
            }
            sqlCON.Close();
        }

        private void addToCartButton_Click(object sender, EventArgs e)
        {
            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into CartTable values ('" + 1 + "','" + itemIDTextBox.Text + "','" + itemNameTextBox.Text + "','" + itemCategoryTextBox.Text + "','" +
                            itemPriceTextBox.Text + "')";
            cmd.ExecuteNonQuery();

            sqlCON.Close();
        }

        private void campListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.gearTableTableAdapter.FillByItemName(this.partyOutdoorsDBDataSet.GearTable, campListBox.SelectedItem.ToString());

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Party_Outdoors
{
    public partial class CustomerInfoForm : Form
    {
        public static SqlConnection sqlCON = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=G:\CIS466 FA17\CH 11\Party Outdoors\Party Outdoors\PartyOutdoorsDB.mdf;Integrated Security = True; Connect Timeout = 30");

        public CustomerInfoForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            CartForm cart = new CartForm();
            cart.ShowDialog();
            this.Close();

        }

        private bool isValid(TextBox theTextBox)
        {
            bool flag = true;

            if(theTextBox.Text == "")
            {
                MessageBox.Show("Please enter in all the require fields.", "Error");
                theTextBox.Focus();
                flag = false;
            }
            else
            {
                flag = true;
            }

            return flag;
        }

        private void enterInfoButton_Click(object sender, EventArgs e)
        {         

            if (isValid(firstNameTextBox) && isValid(lastNameTextBox) && isValid(addressTextBox) && isValid(cityTextBox)
               && isValid(zipCodeTextBox) && isValid(emailTextBox))
            {
                if (stateListBox.SelectedIndex > 0)
                {
                    sqlCON.Open();
                    SqlCommand cmd = sqlCON.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into CustomerInfoTable values ('" + 1 + "','" + firstNameTextBox.Text + "','" + lastNameTextBox.Text + "','" + addressTextBox.Text + "','" +
                                    cityTextBox.Text + "','" + stateListBox.SelectedItem + "','" + zipCodeTextBox.Text + "','" + emailTextBox.Text + "')";
                    cmd.ExecuteNonQuery();
                                       
                    sqlCON.Close();
                    
                }
                else
                {
                    MessageBox.Show("Please select a state.", "State Selection Null");
                }
                invoiceButton.Visible = true;
                enterInfoButton.Visible = false;

                this.Validate();
                this.customerInfoTableBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.customerInfoDataSet);
            }
        }

        private void customerInfoTableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customerInfoTableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.customerInfoDataSet);

        }

        private void CustomerInfoForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customerInfoDataSet.CustomerInfoTable' table. You can move, or remove it, as needed.
            this.customerInfoTableTableAdapter.Fill(this.customerInfoDataSet.CustomerInfoTable);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Party_Outdoors
{
    public partial class BikeForm : Form
    {

        public static SqlConnection sqlCON = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=G:\CIS466 FA17\CH 11\Party Outdoors\Party Outdoors\PartyOutdoorsDB.mdf;Integrated Security = True; Connect Timeout = 30");
        
        public BikeForm()
        {
            InitializeComponent();
            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                if (dr["Tag"].ToString() == "Bike")
                {
                    bikesListBox.Items.Add(dr["ItemName"]).ToString();
                }

                               
            }                      

            sqlCON.Close();
        }

        private void checkoutBButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerInfoForm CustomerInfoForm = new CustomerInfoForm();
            CustomerInfoForm.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm MainForm = new MainForm();
            MainForm.ShowDialog();
            this.Close();
        }

        private void gearTableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.gearTableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.partyOutdoorsDBDataSet);

        }

        private void BikeForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'partyOutdoorsDBDataSet.GearTable' table. You can move, or remove it, as needed.
            //this.gearTableTableAdapter.FillByBike(this.partyOutdoorsDBDataSet.GearTable);

        }

        private void showHelmetsButton_Click(object sender, EventArgs e)
        {
            bikesListBox.Items.Clear();
            this.gearTableTableAdapter.FillByHelmet(this.partyOutdoorsDBDataSet.GearTable);
            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "Helmet")
                {
                    bikesListBox.Items.Add(dr["ItemName"]).ToString();
                }                
            }
            sqlCON.Close();
        }

        private void showBikesButton_Click(object sender, EventArgs e)
        {
            bikesListBox.Items.Clear();
            this.gearTableTableAdapter.FillByBikes(this.partyOutdoorsDBDataSet.GearTable);

            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "Bike")
                {
                    bikesListBox.Items.Add(dr["ItemName"]).ToString();
                }
            }
            sqlCON.Close();
        }

        private void showShoesButton_Click(object sender, EventArgs e)
        {
            bikesListBox.Items.Clear();

            this.gearTableTableAdapter.FillByShoes(this.partyOutdoorsDBDataSet.GearTable);

            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "Shoes")
                {
                    bikesListBox.Items.Add(dr["ItemName"]).ToString();
                }
            }
            sqlCON.Close();
        }

        private void bikesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.gearTableTableAdapter.FillByItemName(this.partyOutdoorsDBDataSet.GearTable, bikesListBox.SelectedItem.ToString());
        }

        private void addToCartButton_Click(object sender, EventArgs e)
        {
            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into CartTable values ('" + 1 + "','" + itemIDTextBox.Text + "','" + itemNameTextBox.Text + "','" + itemCategoryTextBox.Text + "','" +
                            itemPriceTextBox.Text + "')";
            cmd.ExecuteNonQuery();

            sqlCON.Close();

            
        }
    }
}

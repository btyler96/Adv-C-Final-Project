﻿namespace Party_Outdoors
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.campButton = new System.Windows.Forms.Button();
            this.bikeButton = new System.Windows.Forms.Button();
            this.paddleButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // campButton
            // 
            this.campButton.BackColor = System.Drawing.Color.Aqua;
            this.campButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("campButton.BackgroundImage")));
            this.campButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.campButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.campButton.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.campButton.ForeColor = System.Drawing.Color.White;
            this.campButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.campButton.Location = new System.Drawing.Point(-4, 195);
            this.campButton.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.campButton.Name = "campButton";
            this.campButton.Size = new System.Drawing.Size(382, 88);
            this.campButton.TabIndex = 0;
            this.campButton.Text = "Camp";
            this.campButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.campButton.UseVisualStyleBackColor = false;
            this.campButton.Click += new System.EventHandler(this.campButton_Click);
            // 
            // bikeButton
            // 
            this.bikeButton.BackColor = System.Drawing.Color.Gray;
            this.bikeButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bikeButton.BackgroundImage")));
            this.bikeButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bikeButton.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bikeButton.Location = new System.Drawing.Point(-4, 112);
            this.bikeButton.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.bikeButton.Name = "bikeButton";
            this.bikeButton.Size = new System.Drawing.Size(382, 86);
            this.bikeButton.TabIndex = 1;
            this.bikeButton.Text = "Bike";
            this.bikeButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bikeButton.UseVisualStyleBackColor = false;
            this.bikeButton.Click += new System.EventHandler(this.bikeButton_Click);
            // 
            // paddleButton
            // 
            this.paddleButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.paddleButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("paddleButton.BackgroundImage")));
            this.paddleButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.paddleButton.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paddleButton.Location = new System.Drawing.Point(-4, 278);
            this.paddleButton.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.paddleButton.Name = "paddleButton";
            this.paddleButton.Size = new System.Drawing.Size(382, 96);
            this.paddleButton.TabIndex = 2;
            this.paddleButton.Text = "Paddle";
            this.paddleButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.paddleButton.UseVisualStyleBackColor = false;
            this.paddleButton.Click += new System.EventHandler(this.paddleButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(318, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Welcome to Party Outdoors!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(95, 62);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Shop by Clicking Below";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(371, 371);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.campButton);
            this.Controls.Add(this.paddleButton);
            this.Controls.Add(this.bikeButton);
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "MainForm";
            this.Text = "Main Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button campButton;
        private System.Windows.Forms.Button bikeButton;
        private System.Windows.Forms.Button paddleButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}


﻿namespace Party_Outdoors
{
    partial class PaddleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label itemIDLabel;
            System.Windows.Forms.Label itemNameLabel;
            System.Windows.Forms.Label itemBrandLabel;
            System.Windows.Forms.Label itemCategoryLabel;
            System.Windows.Forms.Label itemPriceLabel;
            System.Windows.Forms.Label tagLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PaddleForm));
            this.checkoutPButton = new System.Windows.Forms.Button();
            this.backPButton = new System.Windows.Forms.Button();
            this.partyOutdoorsDBDataSet = new Party_Outdoors.PartyOutdoorsDBDataSet();
            this.gearTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gearTableTableAdapter = new Party_Outdoors.PartyOutdoorsDBDataSetTableAdapters.GearTableTableAdapter();
            this.tableAdapterManager = new Party_Outdoors.PartyOutdoorsDBDataSetTableAdapters.TableAdapterManager();
            this.gearTableBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.gearTableBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.showPaddlesButton = new System.Windows.Forms.Button();
            this.showBoatsButton = new System.Windows.Forms.Button();
            this.showPFDButton = new System.Windows.Forms.Button();
            this.gearTableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.itemIDTextBox = new System.Windows.Forms.TextBox();
            this.itemNameTextBox = new System.Windows.Forms.TextBox();
            this.itemBrandTextBox = new System.Windows.Forms.TextBox();
            this.itemCategoryTextBox = new System.Windows.Forms.TextBox();
            this.itemPriceTextBox = new System.Windows.Forms.TextBox();
            this.tagTextBox = new System.Windows.Forms.TextBox();
            this.paddlingListBox = new System.Windows.Forms.ListBox();
            this.addToCartButton = new System.Windows.Forms.Button();
            itemIDLabel = new System.Windows.Forms.Label();
            itemNameLabel = new System.Windows.Forms.Label();
            itemBrandLabel = new System.Windows.Forms.Label();
            itemCategoryLabel = new System.Windows.Forms.Label();
            itemPriceLabel = new System.Windows.Forms.Label();
            tagLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.partyOutdoorsDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingNavigator)).BeginInit();
            this.gearTableBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // itemIDLabel
            // 
            itemIDLabel.AutoSize = true;
            itemIDLabel.Location = new System.Drawing.Point(183, 55);
            itemIDLabel.Name = "itemIDLabel";
            itemIDLabel.Size = new System.Drawing.Size(44, 13);
            itemIDLabel.TabIndex = 22;
            itemIDLabel.Text = "Item ID:";
            // 
            // itemNameLabel
            // 
            itemNameLabel.AutoSize = true;
            itemNameLabel.Location = new System.Drawing.Point(183, 81);
            itemNameLabel.Name = "itemNameLabel";
            itemNameLabel.Size = new System.Drawing.Size(61, 13);
            itemNameLabel.TabIndex = 24;
            itemNameLabel.Text = "Item Name:";
            // 
            // itemBrandLabel
            // 
            itemBrandLabel.AutoSize = true;
            itemBrandLabel.Location = new System.Drawing.Point(183, 107);
            itemBrandLabel.Name = "itemBrandLabel";
            itemBrandLabel.Size = new System.Drawing.Size(61, 13);
            itemBrandLabel.TabIndex = 26;
            itemBrandLabel.Text = "Item Brand:";
            // 
            // itemCategoryLabel
            // 
            itemCategoryLabel.AutoSize = true;
            itemCategoryLabel.Location = new System.Drawing.Point(183, 133);
            itemCategoryLabel.Name = "itemCategoryLabel";
            itemCategoryLabel.Size = new System.Drawing.Size(75, 13);
            itemCategoryLabel.TabIndex = 28;
            itemCategoryLabel.Text = "Item Category:";
            // 
            // itemPriceLabel
            // 
            itemPriceLabel.AutoSize = true;
            itemPriceLabel.Location = new System.Drawing.Point(183, 159);
            itemPriceLabel.Name = "itemPriceLabel";
            itemPriceLabel.Size = new System.Drawing.Size(57, 13);
            itemPriceLabel.TabIndex = 30;
            itemPriceLabel.Text = "Item Price:";
            // 
            // tagLabel
            // 
            tagLabel.AutoSize = true;
            tagLabel.Location = new System.Drawing.Point(183, 185);
            tagLabel.Name = "tagLabel";
            tagLabel.Size = new System.Drawing.Size(29, 13);
            tagLabel.TabIndex = 32;
            tagLabel.Text = "Tag:";
            // 
            // checkoutPButton
            // 
            this.checkoutPButton.AutoSize = true;
            this.checkoutPButton.BackColor = System.Drawing.Color.Lime;
            this.checkoutPButton.Font = new System.Drawing.Font("Showcard Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkoutPButton.Location = new System.Drawing.Point(288, 249);
            this.checkoutPButton.Margin = new System.Windows.Forms.Padding(1);
            this.checkoutPButton.Name = "checkoutPButton";
            this.checkoutPButton.Size = new System.Drawing.Size(76, 29);
            this.checkoutPButton.TabIndex = 0;
            this.checkoutPButton.Text = "Checkout";
            this.checkoutPButton.UseVisualStyleBackColor = false;
            this.checkoutPButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // backPButton
            // 
            this.backPButton.AutoSize = true;
            this.backPButton.BackColor = System.Drawing.Color.Lime;
            this.backPButton.Font = new System.Drawing.Font("Showcard Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backPButton.Location = new System.Drawing.Point(10, 249);
            this.backPButton.Margin = new System.Windows.Forms.Padding(1);
            this.backPButton.Name = "backPButton";
            this.backPButton.Size = new System.Drawing.Size(66, 29);
            this.backPButton.TabIndex = 1;
            this.backPButton.Text = "Back";
            this.backPButton.UseVisualStyleBackColor = false;
            this.backPButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // partyOutdoorsDBDataSet
            // 
            this.partyOutdoorsDBDataSet.DataSetName = "PartyOutdoorsDBDataSet";
            this.partyOutdoorsDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gearTableBindingSource
            // 
            this.gearTableBindingSource.DataMember = "GearTable";
            this.gearTableBindingSource.DataSource = this.partyOutdoorsDBDataSet;
            // 
            // gearTableTableAdapter
            // 
            this.gearTableTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.GearTableTableAdapter = this.gearTableTableAdapter;
            this.tableAdapterManager.UpdateOrder = Party_Outdoors.PartyOutdoorsDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // gearTableBindingNavigator
            // 
            this.gearTableBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.gearTableBindingNavigator.BindingSource = this.gearTableBindingSource;
            this.gearTableBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.gearTableBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.gearTableBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.gearTableBindingNavigatorSaveItem});
            this.gearTableBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.gearTableBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.gearTableBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.gearTableBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.gearTableBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.gearTableBindingNavigator.Name = "gearTableBindingNavigator";
            this.gearTableBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.gearTableBindingNavigator.Size = new System.Drawing.Size(372, 25);
            this.gearTableBindingNavigator.TabIndex = 2;
            this.gearTableBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // gearTableBindingNavigatorSaveItem
            // 
            this.gearTableBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.gearTableBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("gearTableBindingNavigatorSaveItem.Image")));
            this.gearTableBindingNavigatorSaveItem.Name = "gearTableBindingNavigatorSaveItem";
            this.gearTableBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.gearTableBindingNavigatorSaveItem.Text = "Save Data";
            this.gearTableBindingNavigatorSaveItem.Click += new System.EventHandler(this.gearTableBindingNavigatorSaveItem_Click);
            // 
            // showPaddlesButton
            // 
            this.showPaddlesButton.Location = new System.Drawing.Point(53, 55);
            this.showPaddlesButton.Name = "showPaddlesButton";
            this.showPaddlesButton.Size = new System.Drawing.Size(75, 23);
            this.showPaddlesButton.TabIndex = 21;
            this.showPaddlesButton.Text = "Paddles";
            this.showPaddlesButton.UseVisualStyleBackColor = true;
            this.showPaddlesButton.Click += new System.EventHandler(this.showPaddlesButton_Click);
            // 
            // showBoatsButton
            // 
            this.showBoatsButton.Location = new System.Drawing.Point(93, 28);
            this.showBoatsButton.Name = "showBoatsButton";
            this.showBoatsButton.Size = new System.Drawing.Size(75, 23);
            this.showBoatsButton.TabIndex = 20;
            this.showBoatsButton.Text = "Boats";
            this.showBoatsButton.UseVisualStyleBackColor = true;
            this.showBoatsButton.Click += new System.EventHandler(this.showBoatsButton_Click);
            // 
            // showPFDButton
            // 
            this.showPFDButton.Location = new System.Drawing.Point(12, 28);
            this.showPFDButton.Name = "showPFDButton";
            this.showPFDButton.Size = new System.Drawing.Size(75, 23);
            this.showPFDButton.TabIndex = 19;
            this.showPFDButton.Text = "PFD";
            this.showPFDButton.UseVisualStyleBackColor = true;
            this.showPFDButton.Click += new System.EventHandler(this.showPFDButton_Click);
            // 
            // gearTableBindingSource1
            // 
            this.gearTableBindingSource1.DataMember = "GearTable";
            this.gearTableBindingSource1.DataSource = this.partyOutdoorsDBDataSet;
            // 
            // itemIDTextBox
            // 
            this.itemIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemID", true));
            this.itemIDTextBox.Location = new System.Drawing.Point(264, 52);
            this.itemIDTextBox.Name = "itemIDTextBox";
            this.itemIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemIDTextBox.TabIndex = 23;
            // 
            // itemNameTextBox
            // 
            this.itemNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemName", true));
            this.itemNameTextBox.Location = new System.Drawing.Point(264, 78);
            this.itemNameTextBox.Name = "itemNameTextBox";
            this.itemNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemNameTextBox.TabIndex = 25;
            // 
            // itemBrandTextBox
            // 
            this.itemBrandTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemBrand", true));
            this.itemBrandTextBox.Location = new System.Drawing.Point(264, 104);
            this.itemBrandTextBox.Name = "itemBrandTextBox";
            this.itemBrandTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemBrandTextBox.TabIndex = 27;
            // 
            // itemCategoryTextBox
            // 
            this.itemCategoryTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemCategory", true));
            this.itemCategoryTextBox.Location = new System.Drawing.Point(264, 130);
            this.itemCategoryTextBox.Name = "itemCategoryTextBox";
            this.itemCategoryTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemCategoryTextBox.TabIndex = 29;
            // 
            // itemPriceTextBox
            // 
            this.itemPriceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemPrice", true));
            this.itemPriceTextBox.Location = new System.Drawing.Point(264, 156);
            this.itemPriceTextBox.Name = "itemPriceTextBox";
            this.itemPriceTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemPriceTextBox.TabIndex = 31;
            // 
            // tagTextBox
            // 
            this.tagTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "Tag", true));
            this.tagTextBox.Location = new System.Drawing.Point(264, 182);
            this.tagTextBox.Name = "tagTextBox";
            this.tagTextBox.Size = new System.Drawing.Size(100, 20);
            this.tagTextBox.TabIndex = 33;
            // 
            // paddlingListBox
            // 
            this.paddlingListBox.FormattingEnabled = true;
            this.paddlingListBox.Location = new System.Drawing.Point(30, 94);
            this.paddlingListBox.Name = "paddlingListBox";
            this.paddlingListBox.Size = new System.Drawing.Size(120, 95);
            this.paddlingListBox.TabIndex = 34;
            this.paddlingListBox.SelectedIndexChanged += new System.EventHandler(this.paddlingListBox_SelectedIndexChanged);
            // 
            // addToCartButton
            // 
            this.addToCartButton.BackColor = System.Drawing.Color.Lime;
            this.addToCartButton.Font = new System.Drawing.Font("Showcard Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addToCartButton.Location = new System.Drawing.Point(264, 208);
            this.addToCartButton.Name = "addToCartButton";
            this.addToCartButton.Size = new System.Drawing.Size(100, 29);
            this.addToCartButton.TabIndex = 35;
            this.addToCartButton.Text = "Add to Cart";
            this.addToCartButton.UseVisualStyleBackColor = false;
            this.addToCartButton.Click += new System.EventHandler(this.addToCartButton_Click);
            // 
            // PaddleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 288);
            this.Controls.Add(this.addToCartButton);
            this.Controls.Add(this.paddlingListBox);
            this.Controls.Add(itemIDLabel);
            this.Controls.Add(this.itemIDTextBox);
            this.Controls.Add(itemNameLabel);
            this.Controls.Add(this.itemNameTextBox);
            this.Controls.Add(itemBrandLabel);
            this.Controls.Add(this.itemBrandTextBox);
            this.Controls.Add(itemCategoryLabel);
            this.Controls.Add(this.itemCategoryTextBox);
            this.Controls.Add(itemPriceLabel);
            this.Controls.Add(this.itemPriceTextBox);
            this.Controls.Add(tagLabel);
            this.Controls.Add(this.tagTextBox);
            this.Controls.Add(this.showPaddlesButton);
            this.Controls.Add(this.showBoatsButton);
            this.Controls.Add(this.showPFDButton);
            this.Controls.Add(this.gearTableBindingNavigator);
            this.Controls.Add(this.backPButton);
            this.Controls.Add(this.checkoutPButton);
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "PaddleForm";
            this.Text = "PaddleForm";
            this.Load += new System.EventHandler(this.PaddleForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.partyOutdoorsDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingNavigator)).EndInit();
            this.gearTableBindingNavigator.ResumeLayout(false);
            this.gearTableBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button checkoutPButton;
        private System.Windows.Forms.Button backPButton;
        private PartyOutdoorsDBDataSet partyOutdoorsDBDataSet;
        private System.Windows.Forms.BindingSource gearTableBindingSource;
        private PartyOutdoorsDBDataSetTableAdapters.GearTableTableAdapter gearTableTableAdapter;
        private PartyOutdoorsDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator gearTableBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton gearTableBindingNavigatorSaveItem;
        private System.Windows.Forms.Button showPaddlesButton;
        private System.Windows.Forms.Button showBoatsButton;
        private System.Windows.Forms.Button showPFDButton;
        private System.Windows.Forms.BindingSource gearTableBindingSource1;
        private System.Windows.Forms.TextBox itemIDTextBox;
        private System.Windows.Forms.TextBox itemNameTextBox;
        private System.Windows.Forms.TextBox itemBrandTextBox;
        private System.Windows.Forms.TextBox itemCategoryTextBox;
        private System.Windows.Forms.TextBox itemPriceTextBox;
        private System.Windows.Forms.TextBox tagTextBox;
        private System.Windows.Forms.ListBox paddlingListBox;
        private System.Windows.Forms.Button addToCartButton;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Party_Outdoors
{
    public partial class MainForm : Form
    {

        public MainForm()
        {
            InitializeComponent();

            
        }

        private void campButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            CampForm CampForm = new CampForm();
            CampForm.ShowDialog();
            this.Close();
        }

        private void paddleButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            PaddleForm PaddleForm = new PaddleForm();
            PaddleForm.ShowDialog();
            this.Close();
        }

        private void bikeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            BikeForm BikeForm = new BikeForm();
            BikeForm.ShowDialog();
            this.Close();
        }
        
    }
}

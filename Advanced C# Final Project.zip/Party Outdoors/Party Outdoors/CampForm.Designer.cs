﻿namespace Party_Outdoors
{
    partial class CampForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label itemIDLabel;
            System.Windows.Forms.Label itemNameLabel;
            System.Windows.Forms.Label itemBrandLabel;
            System.Windows.Forms.Label itemCategoryLabel;
            System.Windows.Forms.Label itemPriceLabel;
            System.Windows.Forms.Label tagLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CampForm));
            this.checkoutCButton = new System.Windows.Forms.Button();
            this.backCButton = new System.Windows.Forms.Button();
            this.partyOutdoorsDBDataSet = new Party_Outdoors.PartyOutdoorsDBDataSet();
            this.gearTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gearTableTableAdapter = new Party_Outdoors.PartyOutdoorsDBDataSetTableAdapters.GearTableTableAdapter();
            this.tableAdapterManager = new Party_Outdoors.PartyOutdoorsDBDataSetTableAdapters.TableAdapterManager();
            this.gearTableBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.gearTableBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.gearTableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.showPacksButton = new System.Windows.Forms.Button();
            this.showSleepingBagsButton = new System.Windows.Forms.Button();
            this.showTentsButton = new System.Windows.Forms.Button();
            this.itemIDTextBox = new System.Windows.Forms.TextBox();
            this.itemNameTextBox = new System.Windows.Forms.TextBox();
            this.itemBrandTextBox = new System.Windows.Forms.TextBox();
            this.itemCategoryTextBox = new System.Windows.Forms.TextBox();
            this.itemPriceTextBox = new System.Windows.Forms.TextBox();
            this.tagTextBox = new System.Windows.Forms.TextBox();
            this.campListBox = new System.Windows.Forms.ListBox();
            this.addToCartButton = new System.Windows.Forms.Button();
            itemIDLabel = new System.Windows.Forms.Label();
            itemNameLabel = new System.Windows.Forms.Label();
            itemBrandLabel = new System.Windows.Forms.Label();
            itemCategoryLabel = new System.Windows.Forms.Label();
            itemPriceLabel = new System.Windows.Forms.Label();
            tagLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.partyOutdoorsDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingNavigator)).BeginInit();
            this.gearTableBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // itemIDLabel
            // 
            itemIDLabel.AutoSize = true;
            itemIDLabel.Location = new System.Drawing.Point(181, 58);
            itemIDLabel.Name = "itemIDLabel";
            itemIDLabel.Size = new System.Drawing.Size(44, 13);
            itemIDLabel.TabIndex = 21;
            itemIDLabel.Text = "Item ID:";
            // 
            // itemNameLabel
            // 
            itemNameLabel.AutoSize = true;
            itemNameLabel.Location = new System.Drawing.Point(181, 84);
            itemNameLabel.Name = "itemNameLabel";
            itemNameLabel.Size = new System.Drawing.Size(61, 13);
            itemNameLabel.TabIndex = 23;
            itemNameLabel.Text = "Item Name:";
            // 
            // itemBrandLabel
            // 
            itemBrandLabel.AutoSize = true;
            itemBrandLabel.Location = new System.Drawing.Point(181, 110);
            itemBrandLabel.Name = "itemBrandLabel";
            itemBrandLabel.Size = new System.Drawing.Size(61, 13);
            itemBrandLabel.TabIndex = 25;
            itemBrandLabel.Text = "Item Brand:";
            // 
            // itemCategoryLabel
            // 
            itemCategoryLabel.AutoSize = true;
            itemCategoryLabel.Location = new System.Drawing.Point(181, 136);
            itemCategoryLabel.Name = "itemCategoryLabel";
            itemCategoryLabel.Size = new System.Drawing.Size(75, 13);
            itemCategoryLabel.TabIndex = 27;
            itemCategoryLabel.Text = "Item Category:";
            // 
            // itemPriceLabel
            // 
            itemPriceLabel.AutoSize = true;
            itemPriceLabel.Location = new System.Drawing.Point(181, 162);
            itemPriceLabel.Name = "itemPriceLabel";
            itemPriceLabel.Size = new System.Drawing.Size(57, 13);
            itemPriceLabel.TabIndex = 29;
            itemPriceLabel.Text = "Item Price:";
            // 
            // tagLabel
            // 
            tagLabel.AutoSize = true;
            tagLabel.Location = new System.Drawing.Point(181, 188);
            tagLabel.Name = "tagLabel";
            tagLabel.Size = new System.Drawing.Size(29, 13);
            tagLabel.TabIndex = 31;
            tagLabel.Text = "Tag:";
            // 
            // checkoutCButton
            // 
            this.checkoutCButton.AutoSize = true;
            this.checkoutCButton.BackColor = System.Drawing.Color.Lime;
            this.checkoutCButton.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkoutCButton.Location = new System.Drawing.Point(281, 254);
            this.checkoutCButton.Margin = new System.Windows.Forms.Padding(1);
            this.checkoutCButton.Name = "checkoutCButton";
            this.checkoutCButton.Size = new System.Drawing.Size(81, 35);
            this.checkoutCButton.TabIndex = 0;
            this.checkoutCButton.Text = "Checkout";
            this.checkoutCButton.UseVisualStyleBackColor = false;
            this.checkoutCButton.Click += new System.EventHandler(this.checkoutCButton_Click);
            // 
            // backCButton
            // 
            this.backCButton.AutoSize = true;
            this.backCButton.BackColor = System.Drawing.Color.Lime;
            this.backCButton.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backCButton.Location = new System.Drawing.Point(10, 254);
            this.backCButton.Margin = new System.Windows.Forms.Padding(1);
            this.backCButton.Name = "backCButton";
            this.backCButton.Size = new System.Drawing.Size(71, 35);
            this.backCButton.TabIndex = 1;
            this.backCButton.Text = "Back";
            this.backCButton.UseVisualStyleBackColor = false;
            this.backCButton.Click += new System.EventHandler(this.backCButton_Click);
            // 
            // partyOutdoorsDBDataSet
            // 
            this.partyOutdoorsDBDataSet.DataSetName = "PartyOutdoorsDBDataSet";
            this.partyOutdoorsDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gearTableBindingSource
            // 
            this.gearTableBindingSource.DataMember = "GearTable";
            this.gearTableBindingSource.DataSource = this.partyOutdoorsDBDataSet;
            // 
            // gearTableTableAdapter
            // 
            this.gearTableTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.GearTableTableAdapter = this.gearTableTableAdapter;
            this.tableAdapterManager.UpdateOrder = Party_Outdoors.PartyOutdoorsDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // gearTableBindingNavigator
            // 
            this.gearTableBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.gearTableBindingNavigator.BindingSource = this.gearTableBindingSource;
            this.gearTableBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.gearTableBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.gearTableBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.gearTableBindingNavigatorSaveItem});
            this.gearTableBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.gearTableBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.gearTableBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.gearTableBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.gearTableBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.gearTableBindingNavigator.Name = "gearTableBindingNavigator";
            this.gearTableBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.gearTableBindingNavigator.Size = new System.Drawing.Size(372, 25);
            this.gearTableBindingNavigator.TabIndex = 2;
            this.gearTableBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // gearTableBindingNavigatorSaveItem
            // 
            this.gearTableBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.gearTableBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("gearTableBindingNavigatorSaveItem.Image")));
            this.gearTableBindingNavigatorSaveItem.Name = "gearTableBindingNavigatorSaveItem";
            this.gearTableBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.gearTableBindingNavigatorSaveItem.Text = "Save Data";
            this.gearTableBindingNavigatorSaveItem.Click += new System.EventHandler(this.gearTableBindingNavigatorSaveItem_Click);
            // 
            // gearTableBindingSource1
            // 
            this.gearTableBindingSource1.DataMember = "GearTable";
            this.gearTableBindingSource1.DataSource = this.partyOutdoorsDBDataSet;
            // 
            // showPacksButton
            // 
            this.showPacksButton.Location = new System.Drawing.Point(47, 55);
            this.showPacksButton.Name = "showPacksButton";
            this.showPacksButton.Size = new System.Drawing.Size(75, 23);
            this.showPacksButton.TabIndex = 21;
            this.showPacksButton.Text = "Packs";
            this.showPacksButton.UseVisualStyleBackColor = true;
            this.showPacksButton.Click += new System.EventHandler(this.showPacksButton_Click);
            // 
            // showSleepingBagsButton
            // 
            this.showSleepingBagsButton.Location = new System.Drawing.Point(87, 28);
            this.showSleepingBagsButton.Name = "showSleepingBagsButton";
            this.showSleepingBagsButton.Size = new System.Drawing.Size(88, 23);
            this.showSleepingBagsButton.TabIndex = 20;
            this.showSleepingBagsButton.Text = "Sleeping Bags";
            this.showSleepingBagsButton.UseVisualStyleBackColor = true;
            this.showSleepingBagsButton.Click += new System.EventHandler(this.showSleepingBagsButton_Click);
            // 
            // showTentsButton
            // 
            this.showTentsButton.Location = new System.Drawing.Point(6, 28);
            this.showTentsButton.Name = "showTentsButton";
            this.showTentsButton.Size = new System.Drawing.Size(75, 23);
            this.showTentsButton.TabIndex = 19;
            this.showTentsButton.Text = "Tents";
            this.showTentsButton.UseVisualStyleBackColor = true;
            this.showTentsButton.Click += new System.EventHandler(this.showTentsButton_Click);
            // 
            // itemIDTextBox
            // 
            this.itemIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemID", true));
            this.itemIDTextBox.Location = new System.Drawing.Point(262, 55);
            this.itemIDTextBox.Name = "itemIDTextBox";
            this.itemIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemIDTextBox.TabIndex = 22;
            // 
            // itemNameTextBox
            // 
            this.itemNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemName", true));
            this.itemNameTextBox.Location = new System.Drawing.Point(262, 81);
            this.itemNameTextBox.Name = "itemNameTextBox";
            this.itemNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemNameTextBox.TabIndex = 24;
            // 
            // itemBrandTextBox
            // 
            this.itemBrandTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemBrand", true));
            this.itemBrandTextBox.Location = new System.Drawing.Point(262, 107);
            this.itemBrandTextBox.Name = "itemBrandTextBox";
            this.itemBrandTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemBrandTextBox.TabIndex = 26;
            // 
            // itemCategoryTextBox
            // 
            this.itemCategoryTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemCategory", true));
            this.itemCategoryTextBox.Location = new System.Drawing.Point(262, 133);
            this.itemCategoryTextBox.Name = "itemCategoryTextBox";
            this.itemCategoryTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemCategoryTextBox.TabIndex = 28;
            // 
            // itemPriceTextBox
            // 
            this.itemPriceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "ItemPrice", true));
            this.itemPriceTextBox.Location = new System.Drawing.Point(262, 159);
            this.itemPriceTextBox.Name = "itemPriceTextBox";
            this.itemPriceTextBox.Size = new System.Drawing.Size(100, 20);
            this.itemPriceTextBox.TabIndex = 30;
            // 
            // tagTextBox
            // 
            this.tagTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gearTableBindingSource, "Tag", true));
            this.tagTextBox.Location = new System.Drawing.Point(262, 185);
            this.tagTextBox.Name = "tagTextBox";
            this.tagTextBox.Size = new System.Drawing.Size(100, 20);
            this.tagTextBox.TabIndex = 32;
            // 
            // campListBox
            // 
            this.campListBox.FormattingEnabled = true;
            this.campListBox.Location = new System.Drawing.Point(29, 94);
            this.campListBox.Name = "campListBox";
            this.campListBox.Size = new System.Drawing.Size(120, 95);
            this.campListBox.TabIndex = 33;
            this.campListBox.SelectedIndexChanged += new System.EventHandler(this.campListBox_SelectedIndexChanged);
            // 
            // addToCartButton
            // 
            this.addToCartButton.BackColor = System.Drawing.Color.Lime;
            this.addToCartButton.Font = new System.Drawing.Font("Showcard Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addToCartButton.Location = new System.Drawing.Point(262, 211);
            this.addToCartButton.Name = "addToCartButton";
            this.addToCartButton.Size = new System.Drawing.Size(100, 29);
            this.addToCartButton.TabIndex = 36;
            this.addToCartButton.Text = "Add to Cart";
            this.addToCartButton.UseVisualStyleBackColor = false;
            this.addToCartButton.Click += new System.EventHandler(this.addToCartButton_Click);
            // 
            // CampForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 299);
            this.Controls.Add(this.addToCartButton);
            this.Controls.Add(this.campListBox);
            this.Controls.Add(itemIDLabel);
            this.Controls.Add(this.itemIDTextBox);
            this.Controls.Add(itemNameLabel);
            this.Controls.Add(this.itemNameTextBox);
            this.Controls.Add(itemBrandLabel);
            this.Controls.Add(this.itemBrandTextBox);
            this.Controls.Add(itemCategoryLabel);
            this.Controls.Add(this.itemCategoryTextBox);
            this.Controls.Add(itemPriceLabel);
            this.Controls.Add(this.itemPriceTextBox);
            this.Controls.Add(tagLabel);
            this.Controls.Add(this.tagTextBox);
            this.Controls.Add(this.showPacksButton);
            this.Controls.Add(this.showSleepingBagsButton);
            this.Controls.Add(this.showTentsButton);
            this.Controls.Add(this.gearTableBindingNavigator);
            this.Controls.Add(this.backCButton);
            this.Controls.Add(this.checkoutCButton);
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "CampForm";
            this.Text = "CampForm";
            this.Load += new System.EventHandler(this.CampForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.partyOutdoorsDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingNavigator)).EndInit();
            this.gearTableBindingNavigator.ResumeLayout(false);
            this.gearTableBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gearTableBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button checkoutCButton;
        private System.Windows.Forms.Button backCButton;
        private PartyOutdoorsDBDataSet partyOutdoorsDBDataSet;
        private System.Windows.Forms.BindingSource gearTableBindingSource;
        private PartyOutdoorsDBDataSetTableAdapters.GearTableTableAdapter gearTableTableAdapter;
        private PartyOutdoorsDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator gearTableBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton gearTableBindingNavigatorSaveItem;
        private System.Windows.Forms.BindingSource gearTableBindingSource1;
        private System.Windows.Forms.Button showPacksButton;
        private System.Windows.Forms.Button showSleepingBagsButton;
        private System.Windows.Forms.Button showTentsButton;
        private System.Windows.Forms.TextBox itemIDTextBox;
        private System.Windows.Forms.TextBox itemNameTextBox;
        private System.Windows.Forms.TextBox itemBrandTextBox;
        private System.Windows.Forms.TextBox itemCategoryTextBox;
        private System.Windows.Forms.TextBox itemPriceTextBox;
        private System.Windows.Forms.TextBox tagTextBox;
        private System.Windows.Forms.ListBox campListBox;
        private System.Windows.Forms.Button addToCartButton;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Party_Outdoors
{
    public partial class PaddleForm : Form
    {
        public static SqlConnection sqlCON = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=G:\CIS466 FA17\CH 11\Party Outdoors\Party Outdoors\PartyOutdoorsDB.mdf;Integrated Security = True; Connect Timeout = 30");

        public PaddleForm()
        {
            InitializeComponent();

            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["Tag"].ToString() == "Paddling")
                {
                    paddlingListBox.Items.Add(dr["ItemName"]).ToString();
                }

            }
            sqlCON.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            CustomerInfoForm customerInfo = new CustomerInfoForm();
            customerInfo.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm MainForm = new MainForm();
            MainForm.ShowDialog();
            this.Close();
        }

        private void gearTableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.gearTableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.partyOutdoorsDBDataSet);

        }

        private void PaddleForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'partyOutdoorsDBDataSet.GearTable' table. You can move, or remove it, as needed.
            //this.gearTableTableAdapter.FillByPaddling(this.partyOutdoorsDBDataSet.GearTable);

        }

        private void showPFDButton_Click(object sender, EventArgs e)
        {
            paddlingListBox.Items.Clear();
            this.gearTableTableAdapter.FillByPFD(this.partyOutdoorsDBDataSet.GearTable);
            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "PFD")
                {
                    paddlingListBox.Items.Add(dr["ItemName"]).ToString();
                }

            }
            sqlCON.Close();
        }

        private void showBoatsButton_Click(object sender, EventArgs e)
        {
            paddlingListBox.Items.Clear();
            this.gearTableTableAdapter.FillByBoats(this.partyOutdoorsDBDataSet.GearTable);

            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "Boats")
                {
                    paddlingListBox.Items.Add(dr["ItemName"]).ToString();
                }

            }
            sqlCON.Close();
        }

        private void showPaddlesButton_Click(object sender, EventArgs e)
        {
            paddlingListBox.Items.Clear();
            this.gearTableTableAdapter.FillByPaddles(this.partyOutdoorsDBDataSet.GearTable);

            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from gearTable";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["ItemCategory"].ToString() == "Paddles")
                {
                    paddlingListBox.Items.Add(dr["ItemName"]).ToString();
                }

            }
            sqlCON.Close();
        }

        private void addToCartButton_Click(object sender, EventArgs e)
        {
            sqlCON.Open();
            SqlCommand cmd = sqlCON.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into CartTable values ('" + 1 + "','" + itemIDTextBox.Text + "','" + itemNameTextBox.Text + "','" + itemCategoryTextBox.Text + "','" +
                            itemPriceTextBox.Text + "')";
            cmd.ExecuteNonQuery();

            sqlCON.Close();
        }

        private void paddlingListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.gearTableTableAdapter.FillByItemName(this.partyOutdoorsDBDataSet.GearTable, paddlingListBox.SelectedItem.ToString());

        }
    }
}

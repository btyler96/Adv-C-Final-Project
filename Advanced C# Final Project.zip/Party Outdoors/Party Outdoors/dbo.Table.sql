﻿CREATE TABLE [dbo].[CartTable]
(
	[SaleID] INT NOT NULL PRIMARY KEY IDENTITY(1, 0), 
    [ItemID] INT NOT NULL, 
    [ItemName] VARCHAR(50) NOT NULL, 
    [ItemCategory] VARCHAR(50) NOT NULL, 
    [ItemPrice] DECIMAL(8, 2) NOT NULL
)

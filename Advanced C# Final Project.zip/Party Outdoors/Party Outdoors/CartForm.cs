﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Party_Outdoors
{
    public partial class CartForm : Form
    {
        public CartForm()
        {
            InitializeComponent();
        }

        private void completeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            InvoiceForm invoice = new InvoiceForm();
            invoice.ShowDialog();
            this.Close();
        }

        private void cartTableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cartTableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.testDataSet);

        }

        private void CartForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testDataSet.CartTable' table. You can move, or remove it, as needed.
            this.cartTableTableAdapter.Fill(this.testDataSet.CartTable);

        }
    }
}
